@echo off
cd /d "%~dp0"
if not exist "index.html" (
 echo Game files missing. Unzip the entire archive before running.
 pause
 exit /b 1
)
start "" "%~dp0index.html"
