# APEX RUSH v44 — Cloudflare Ready

## 바로 실행
- Windows: `PLAY_APEX_RUSH_WINDOWS.bat` 더블클릭
- 또는 로컬 웹서버에서 `index.html` 실행

## Cloudflare 배포
이 폴더는 정적 HTML/CSS/JS 프로젝트입니다. 별도 빌드가 필요 없습니다.

### GitHub → Cloudflare Workers/Pages
1. 이 폴더 내용을 GitHub 저장소 루트에 업로드합니다.
2. Cloudflare에서 Git 저장소를 연결합니다.
3. Framework preset: None
4. Build command: 비워 둠
5. Output / deploy directory: `/` 또는 저장소 루트
6. 배포 후 제공된 주소로 접속합니다.

## v44 변경점
- Netlify 배지용 하단/우측 예약 공간 제거
- 터치 조작부를 실제 화면 안전영역 기준으로 재배치
- 세로 모드 트랙맵/속도계 영역 분리
- 좌/우/BRAKE/NITRO/DRIFT/JUMP/GO 터치 타깃 유지
- Cloudflare에서 별도 빌드 없이 실행 가능
