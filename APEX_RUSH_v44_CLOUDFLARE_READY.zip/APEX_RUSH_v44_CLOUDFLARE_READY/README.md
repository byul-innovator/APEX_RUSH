# APEX RUSH 3D — Windows 사용 안내

## 1. 레이스 게임 실행

ZIP을 **새 폴더에 모두 압축 해제**하고 `apex_racer/START_HERE_WINDOWS.bat`을 더블클릭하세요. **1번**을 선택하면 브라우저 게임이 열립니다. 또는 `index.html`을 Chrome/Edge로 열 수 있습니다. **스타트 그리드 입장**을 눌러야 브라우저가 음악을 재생합니다. 인터넷은 필요하지 않으며 WebGL 하드웨어 가속이 필요합니다.

- W/↑ 가속, S/↓ 브레이크, A/← 및 D/→ 방향 조향, Shift 니트로, 일반 코스 Space 드리프트, P 일시정지. 기본 코너 주행은 보조되며 좌우 키로 차량의 차선과 코너 움직임을 직접 조절합니다. 가장자리에서는 감속하거나 생명을 잃습니다.
- 3랩 완주 후 최종 순위 / 7대, 총 시간, 최고 랩, 충돌 횟수 표시
- 좌측 상단 지도: 연두색 내 차, 빨간색 앞차, 파란색 뒤차. 하단 범례의 아이템·장애물 문구는 제거했습니다. 지도 점 표시는 유지합니다.
- 아이템 획득 시 최대 10초 무적(무적 중 다시 획득해도 시간 연장 없음). SHIELD: 보호막. EMP: 활성 위험 요소 제거. TURBO: 6초 가속 및 니트로 충전
- BGM은 CRUISE / CHASE / DANGER / FINISH 상황에 맞춰 바뀌며 ♫ 버튼으로 켜고 끌 수 있습니다. Web Audio로 합성한 음악입니다.

## 보조 조향과 드리프트

기본 커브는 도로를 따라 안정적으로 주행합니다. A/D 또는 좌/우 화살표를 누르면 차선이 뚜렷하게 바뀌며, 가속 키만 누른다고 자동으로 차선을 변경하지는 않습니다. 일반 코스에서 Space와 조향키를 함께 누르면 드리프트, 타이어 자국, 연기가 발생합니다. 5번 다리에서는 Space가 붕괴 구간 점프 전용입니다. 모바일 화면에는 DRIFT 버튼을 추가했습니다. 급격히 코스를 벗어나면 생명 1개를 잃고 트랙으로 복귀합니다.

## 스타트 연출과 차량·서킷

버튼을 누르면 차량 7대가 출발 그리드에 정차합니다. 3·2·1 카운트와 빨간 스타트 라이트가 진행되고, 트랙 옆 스타터의 신호총 섬광과 발사음에 맞춰 모든 차량의 주행 시계가 동시에 시작됩니다. 플레이어는 W/↑ 또는 화면 GO 버튼으로 가속합니다. 출발 후 진행 시간이 기록됩니다. 차량은 추가 차체 디테일, 조명, 휠 디스크, 에어로 파츠를 갖추고 트랙에는 출발 게이트, 광고 보드, 건축물과 조명이 추가되었습니다. 참조 이미지의 원본 차량이나 상표를 복제한 것은 아닙니다.

## v6 경쟁·충돌·생명 규칙

- 상대 6대는 서로 다른 속도로 달리며 레벨이 올라갈수록 빨라집니다. 플레이어의 일반 최고 속도보다 빠른 차도 있어 니트로, 아이템, 충돌 회피가 순위에 영향을 줍니다.
- 생명은 3개입니다. 보호막이나 BREAKER 없이 장애물, 방해 차량, 상대 차량에 충돌하면 1개를 잃고 차가 회전하면서 밀려납니다. 약 1.5초 뒤 충돌 지점보다 22m 뒤로 복귀하며 2.4초간 재충돌을 막습니다. 생명이 0개면 레이스가 종료되어 다시 시작해야 합니다.
- 브라우저 게임의 수관, 관람석, 피트 유리창, 표지 구조물과 산 배경을 개선했습니다. 고화질 사진과 동일한 사실성은 아니며 오프라인 Three.js 기반의 절차형 3D 모델입니다. 도로에는 새로 제작한 아스팔트 질감, 야간을 제외한 코스에는 파노라마 하늘 자산을 적용했습니다. 이미지 불러오기가 실패하면 절차형 노면과 하늘을 사용합니다.

## 5번 대교 붕괴 점프 이벤트

다리 구간 약 100m 전에서 붕괴 경고가 나고, 처음에는 연결돼 있던 중앙 도로판과 하부 구조물이 무너지며 지도에도 단절 구간이 빨간색으로 표시됩니다. 가속하여 최소 115km/h 정도를 확보한 뒤 끊어진 구간에 접근했을 때 **Space**를 누르세요. 모바일에서는 **JUMP**를 누릅니다. 무적 시간이 없을 때 점프 타이밍이 너무 빠르거나 늦거나 속도가 부족하면 추락하여 생명 1개를 잃고 약 110m 뒤에서 복귀합니다. 아이템 무적 상태에서는 다리 붕괴 구간도 보호됩니다. 상대 차량은 이 구간을 자동으로 뛰어넘습니다. Blender의 5번 장면은 1~49프레임에서 다리가 연결되고 50프레임부터 도로판과 하부가 무너지는 애니메이션을 담습니다.

## Blender 장면 생성

Windows에서 `START_HERE_WINDOWS.bat`의 **2번**을 선택해 코스 번호(1~10)를 입력하거나, **4번**을 선택해 10개 장면을 한꺼번에 생성하세요. `BUILD_V6_SCENE_WINDOWS.bat`과 `BUILD_ALL_10_TRACKS_WINDOWS.bat`을 직접 실행해도 됩니다. Blender가 PATH 또는 기본 `Program Files\Blender Foundation` 설치 폴더에 있으면 배경 실행 후 `APEX_RUSH_track_XX_테마.blend` 및 선택 코스의 미리보기 PNG를 같은 폴더에 저장합니다. 찾지 못하면 Blender의 **Scripting > Open**에서 `BUILD_APEX_V6_BLENDER.py`를 열고 **Run Script**를 누르세요. 이 스크립트는 코스 장면을 생성하며, 동시에 `blender_car_asset.js`를 내보냅니다. 그 뒤 메뉴 **1번**으로 게임을 다시 열면 새 차량 형상이 10개 코스 모두의 플레이어·상대·방해 차량에 적용됩니다. 노면과 하늘은 `assets/`의 원본 질감을 Blender 장면과 게임에서 공유합니다. 10개 코스의 형상 좌표는 `track_data.json`에도 들어 있습니다. 4번 일괄 생성은 시간 절약을 위해 PNG 렌더를 생략합니다. `.blend` 트랙 건축물 전체를 실시간 게임으로 내보내는 방식은 아니므로 장면의 건축·식생을 수정해도 게임에 자동 반영되지는 않습니다.

## 10개 트랙과 카메라

- **1 / 2 / 3** 키 또는 화면 우측 상단 버튼으로 시점을 바꿉니다. **V** 키는 순환합니다. 1은 운전석, 2는 차 앞에서 뒤를 보는 정면 촬영, 3은 차량 뒤 추적 시점입니다. 조작 방향은 모든 시점에서 같습니다.
- 3랩을 완주하면 최종 순위와 함께 **다음 레벨** 버튼이 나타납니다. 메뉴에서 10개 코스를 바로 선택할 수 있으며, 해안·사막·야간 도시·고산·강변 대교·숲·항구·붉은 협곡·노을·섬 코스를 제공합니다. 5번 **RIVER SKY BRIDGE**에서는 강을 가로지르는 높이 있는 교량, 주탑, 케이블과 양쪽 스카이라인을 달립니다. 주변 대형 구조물은 코스 곡선을 기준으로 차로와의 거리를 검사하고, 긴 피트 건물과 관람석은 주행 방향을 따라 배치합니다. 마지막 레벨에서는 다시 달리기를 선택할 수 있습니다.
- 오렌지색 도로 장애물과 분홍색 방해 차량이 나타납니다. 획득 아이템은 무적이 꺼져 있을 때 10초 무적을 부여합니다. 각 종류의 아이템은 환경 설정의 출현 주기에 맞춰 나타납니다. EMP는 현재 활성 위험 요소를 제거하며, 분홍색 BREAKER는 12초 동안 닿는 위험 요소를 제거합니다. 주황색 TURBO는 6초 가속합니다. 자동 선물은 기본 120초 간격이며 환경 설정에서 조정할 수 있습니다.

## 2. Blender에서 장면 확인

메뉴 **2번**은 `apex_scene.blend`를 Blender로 엽니다. 이미 Blender를 켰다면 **File > Open**에서 그 파일을 여세요. 아이템과 방해 차량 미리보기는 `apex_events_preview.blend`를 열면 바로 볼 수 있습니다. 타임라인 **1~72프레임**을 재생하면 아이템 회전과 방해 차량 이동을 볼 수 있습니다. `event_preview.png`는 렌더된 정지 화면입니다. `apex_camera_views.blend`에는 세 개의 카메라가 있고 `camera_1_cockpit.png`, `camera_2_front.png`, `camera_3_chase.png`는 Blender 4.0.2에서 1280×720, 64샘플로 렌더한 시점 참고 화면입니다. `RENDER_CAMERA_VIEWS.py`를 Scripting 탭에서 실행하면 별도 `.blend`와 세 PNG를 다시 생성할 수 있습니다.

`ADD_RACE_EVENT_PREVIEW.py`를 Blender의 Scripting 탭에서 실행하면 현재 장면에 미리보기 오브젝트를 추가하고 별도 `.blend` 파일로 저장합니다. 기존 장면 파일을 덮어쓰지 않습니다. Blender 4.0.2에서 이벤트 애니메이션과 세 카메라 렌더를 실행·확인했습니다.

## 3. MCP와 역할 구분

`blender_mcp.py`는 Blender의 모델·키프레임·렌더를 제어하는 **로컬 stdio MCP 서버**입니다. 사용 중인 MCP 클라이언트에 `mcp_config.example.json`의 실제 절대 경로를 설정해야 동작합니다. Blender 창을 열어 두는 것만으로 이 ChatGPT 대화와 연결되지 않습니다. 서버는 Blender를 별도 백그라운드 프로세스로 실행하며 현재 열린 Windows Blender 창을 직접 조작하지 않습니다.

실제 레이스 규칙, 미니맵, 아이템 효과, 순위, 음악은 `index.html`/`game3d.js`의 브라우저 게임에서 실행됩니다. Blender 스크립트는 레이싱 차량의 삼각형 메시를 브라우저용 자산으로 출력합니다. `.blend` 파일 자체는 브라우저에서 실시간으로 읽지 않습니다.

Three.js r111 라이선스는 `THREE_LICENSE.txt`에 포함되어 있습니다. 이 프로젝트는 오프라인에서 실행 가능한 3D 아케이드 시제품입니다.

## 시각 참고

Pixabay의 레이스카·서킷 사진과 실제 모터스포츠 트랙 사진에서 낮고 넓은 차체, 명료한 조명, 도로와 관람석의 분리, 배경 깊이를 참고했습니다. 원본 사진, 상표, 차량 모델을 복사하거나 프로젝트에 포함하지 않았습니다. 차량과 배경은 자체 생성한 3D 구조물과 새로 제작한 노면·하늘 질감으로 구성되며 사진 수준 렌더를 보장하지 않습니다.

현재 실행 환경에서는 Blender 바이너리를 실행하지 못해 새 Blender 스크립트의 `.blend` 저장과 렌더를 검증하지 못했습니다. Windows에서 **4번**을 실행해 10개 `.blend`와 브라우저용 차량 메시를 생성한 다음 **1번**으로 게임을 실행하세요. Blender 미설치 또는 실행 실패 시 게임에는 기존 차체 모델이 표시됩니다. 이 환경에서는 Blender 실행·렌더와 Windows 브라우저 화면을 확인하지 못했으며, 스크립트 문법과 10코스 레이스 로직 검사를 통과했습니다.

## 시각 품질과 검증 범위

참고 이미지의 차체 반사, 실제 환경 밀도와 이 오프라인 Three.js 게임 사이에는 시각적 차이가 남아 있습니다. 게임에는 흰 도로 경계선, 더 가까운 추적 카메라, 연속된 먼 지형, 수동 조향 및 드리프트를 적용했습니다. 현재 대화 실행 환경에는 Blender 호출 도구와 Windows 브라우저 실행 화면이 없어 실제 렌더를 확인하지 못했습니다. 코드 기반 테스트에서 10개 레벨, 결승·충돌·점프·복귀, 보조 조향·드리프트와 자산 누락 시 대체 경로를 확인했습니다.

## 차량 선택과 최종 우승 연출

레이스 시작 화면의 **레이싱 차량 선택**에서 Crimson GT, Phantom Hyper, Titan Muscle, Summit Rally 네 가지 실루엣을 고를 수 있습니다. 각 형태는 차체 높이, 폭, 보닛, 스포일러, 루프 및 랠리 장식을 다르게 구성했습니다. 충돌 판정과 속도는 동일합니다. 경쟁 차량도 서로 다른 실루엣으로 등장합니다. 최종 10번 코스의 **1위**로 3랩을 마치면 대형 트럭의 도어가 열리고 선물 콘셉트 차량이 나와, 우승자가 트로피를 드는 3D 시상 장면이 재생됩니다. 2위 이하는 기존 완주 결과만 표시됩니다. 이 장면은 게임 내 가상 이벤트이며 실제 자동차 증정이나 자동차 제조사의 공식 제휴를 뜻하지 않습니다.

[참고 데이터셋](https://www.kaggle.com/datasets/alirezaatashnejad/over-20-car-brands-dataset)은 브랜드와 모델 사진을 모은 이미지 자료입니다. 현재 패키지는 해당 이미지 파일을 다운로드하거나 모델을 학습시키지 않았습니다. 이미지 분류 데이터만으로 3D 차량 메시가 생성되지는 않으므로, 네 차종은 별도 제작한 게임용 3D 형태입니다. 데이터셋 원본 이미지를 게임에 넣지 않았으며, 원본의 라이선스 및 개별 사진 이용 조건은 이 환경에서 확인하지 못했습니다.

## 점진 가속·빨간 쾌속·환경 설정
경쟁 차량은 출발 신호 전에는 정지하고, 신호 후 0부터 가속합니다. ⚙ 환경 설정에서 내 차 최고속도, 경쟁 차량 속도 배율과 가속도, 빨간 쾌속 최고속도, 자동 선물 간격 및 다섯 아이템의 출현 간격을 바꿀 수 있습니다. 저장 시 브라우저에 설정을 보관합니다. 아이템별 타이머는 레이스 진행 시간으로 계산하며, 획득하거나 지나친 뒤 지정한 간격이 지나면 다음 아이템이 앞쪽에 등장합니다.
빨간 EXPRESS는 획득한 시점부터 실제 진행 거리 10,000m 동안 자동 가속을 유지합니다. 기본 최고속도는 420km/h입니다. 남은 거리를 화면에 표시하고, 다음 코스로 이동해도 남은 효과를 이어받습니다. 다시 획득하면 10km로 갱신합니다. 무적 효과는 없으며 충돌과 브레이크가 작동합니다. 사고 후 복귀해도 남은 거리는 유지됩니다. 레이스 결과와 시상 중에는 차량이 주행하지 않습니다.
이 버전은 브라우저 실행본을 수정하고 테스트했습니다. 현재 세션에 Unity·Blender MCP가 노출되지 않아 두 프로그램에서 직접 실행한 결과는 포함하지 않습니다.

## 저장값 고정과 차량 색상
환경 설정에서 저장·적용하면 입력값이 고정됩니다. 다시 편집하려면 설정 수정을 누르세요. 저장한 값은 동일 브라우저에서 재실행·코스 이동 후 유지됩니다. 사이트 데이터 삭제 또는 다른 브라우저에서는 저장값을 공유하지 않습니다.
차량은 GT, 하이퍼카, 머슬카, 랠리카, 세단, 로드스터 6종입니다. 8개 기본 색상 또는 색상 선택기로 직접 고른 색을 차체에 적용하고 스타일과 함께 저장합니다.

## 설정 변경 자동 저장
설정 수정 → 숫자 변경 → 저장·적용 또는 닫기를 누르면 새 값이 저장되고 게임에 적용됩니다. 다시 환경 설정을 열어 확인할 수 있습니다. 저장 후에는 값이 잠기며 설정 수정을 눌러 다시 편집합니다.


## Credits
Creator: DreamByul
Studio: FutureAI
Collaboration: biglearn.ai@gmail.com


## v25 layout fix
- Setup/garage screen no longer shows driving controls.
- Setup content scrolls safely on portrait and short landscape screens.
- View controls move away from selectors/start button.
- Race controls reserve a lower-right exclusion zone for host/browser overlays.
- v23/v24 universal responsive, speed tuning, zoom/fullscreen, credits retained.

## v26 garage layout correction
- Setup-screen zoom/fullscreen toolbar is hidden so it cannot cover Start.
- Start Grid is a full-width primary action with clear bottom spacing.
- Creator/FutureAI collaboration credit is placed in normal document flow under Start on setup screen.
- Environment settings remains available at the top-right.
- Race-screen controls, universal responsiveness, speed tuning, zoom/fullscreen during racing, and safe control layout remain intact.


## v28 race UI
- Compact edge-aligned race controls.
- Landscape controls form a thin bottom strip and reserve lower-right host badge space.
- Portrait controls remain above the host badge safe zone.
- Minimap/racebar/view tools shrink on touch screens.
- v27 garage ordering and all previous features retained.


## v29 clean audio UI
- Removed the large in-race BGM/keyboard instruction overlay.
- Added a compact top-right speaker toggle for BGM.
- Existing game controls, responsive race layout, credits, speed tuning and fullscreen/zoom retained.


## v30 clean race HUD
- Removed STEER / A-D / NITRO / SHIFT keyboard-help text from the live race screen.
- Replaced the awkward 1 운전석 / 2 정면 / 3 추적 row with one compact camera icon that cycles views.
- Repositioned Settings, BGM and Camera controls so they do not overlap.
- Reduced and moved zoom/fullscreen tools.
- Kept v29 audio cleanup, v28 bottom controls, v27 garage ordering, universal responsiveness, speed tuning and credits.


## v31 top utility layout
- Camera, BGM and Settings are grouped at the upper-right.
- Zoom / 100% / zoom-in / reset / fullscreen are a compact horizontal second row.
- Removed the long vertical utility rail from portrait play.
- Keeps the road, vehicle and lower driving controls unobstructed.
- Retains all previous responsive, Netlify-safe, audio, camera, speed and credit fixes.
